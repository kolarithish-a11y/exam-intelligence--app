# Exam Intelligence — Deep Static GK Engine v2

This upgrade changes the study sheet from a generic "Static GK" box into an
entity-aware exam-enrichment layer.

## What it adds

- Concerned ministry + department
- Current officeholders where explicitly verified
- Establishment and institutional origin
- Founders / key historical people
- Firsts / landmark facts when verified
- Headquarters
- Mandate / functions
- Related organisations and systems
- Category-specific checklists for Budget, Schemes, Indices/Reports,
  International Organisations, Awards, Environment, Science & Technology,
  Sports and Polity
- Exam traps
- Evidence URLs
- "Needs source enrichment" status instead of invented facts

## Important limitation

A universal current-affairs engine cannot safely invent facts such as "first
Indian to receive X". The engine therefore distinguishes curated verified packs
from fields that require live/source-backed enrichment. The next production
step is to connect a trusted knowledge provider/source crawler and persist the
result in PostgreSQL.

## Included verified packs

- DRDO
- Asian Games

## Install

The GitHub Actions workflow can install the engine into the current repository.
It does not require an AI API key for the verified packs.
