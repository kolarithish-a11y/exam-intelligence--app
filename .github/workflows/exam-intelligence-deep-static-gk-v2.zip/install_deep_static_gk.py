
from pathlib import Path
p=Path("server/app.py")
s=p.read_text()
imp="from static_gk_engine import enrich_article\n"
if imp not in s:
    s=imp+s
# Enrich all article dictionaries at the API boundary without changing ingestion.
needle="return {"
# Replace common list-return sites conservatively.
s=s.replace('items = cache_items[:limit]', 'items = [enrich_article(x) for x in cache_items[:limit]]')
s=s.replace('return results', 'return [enrich_article(x) for x in results]')
s=s.replace('return items', 'return [enrich_article(x) for x in items]')
p.write_text(s)
print("Deep Static-GK engine installed. Review server/app.py integration points.")
