
"""
Deep Static-GK Enrichment Engine
--------------------------------
Entity-aware, exam-oriented enrichment for current-affairs articles.

Design rule: never invent a field. Missing facts remain absent/verification-pending.
The curated packs below are deliberately evidence-backed and are only examples;
the generic category templates explain what the engine should collect once a
trusted source/provider supplies the fact.
"""
from __future__ import annotations
from copy import deepcopy
import re

STATIC_GK_VERSION = "2.0"

def _src(label, url):
    return {"label": label, "url": url}

PACKS = {
    "DRDO": {
        "entity": "Defence Research and Development Organisation (DRDO)",
        "entity_type": "organisation",
        "definition": "India's defence research and development organisation under the Department of Defence Research & Development, Ministry of Defence.",
        "ministry": "Ministry of Defence",
        "department": "Department of Defence Research & Development (DD R&D)",
        "established": "1958",
        "origin_history": [
            "DRDO was formed in 1958 by amalgamating the Technical Development Establishments (TDEs) of the Indian Army and the Directorate of Technical Development & Production (DTDP) with the Defence Science Organisation (DSO).",
            "The Defence Science Organisation was developed under the leadership of Dr Daulat Singh Kothari, who was appointed the first Scientific Adviser in July 1948.",
        ],
        "key_people": [
            "Dr Daulat Singh Kothari — first Scientific Adviser; built the Defence Science Organisation's early scientific base.",
            "Dr A. P. J. Abdul Kalam — former Scientific Adviser to the Raksha Mantri and Director General, DRDO (1992–1999).",
        ],
        "current_officeholders": [
            "Rajesh Kumar Singh, IAS — Secretary, Department of Defence Research & Development and Chairman, DRDO (additional charge, as listed by DRDO).",
            "Rajnath Singh — Raksha Mantri.",
            "Sanjay Seth — Raksha Rajya Mantri.",
        ],
        "headquarters": "New Delhi, India",
        "mandate": [
            "Develop indigenous defence technologies and systems.",
            "Provide technological solutions to the Armed Forces.",
            "Support production and induction of systems developed through the defence R&D ecosystem.",
        ],
        "technology_domains": [
            "Aeronautics", "Armaments", "Combat Vehicles", "Electronics",
            "Engineering Systems", "Instrumentation", "Missiles",
            "Advanced Computing & Simulation", "Naval Systems", "Life Sciences",
            "Special Materials"
        ],
        "landmark_systems": ["Agni", "Prithvi", "Tejas", "Pinaka", "Akash"],
        "exam_traps": [
            "DRDO was formed in 1958; the Defence Science Organisation dates to the earlier post-independence period.",
            "DRDO is under the Department of Defence Research & Development, Ministry of Defence.",
            "Do not confuse the formation of DRDO with the later creation of the Department of Defence Research & Development in 1980.",
        ],
        "sources": [
            _src("DRDO — Organisation", "https://drdo.gov.in/drdo/en/organisation"),
            _src("DRDO — When was DRDO formed?", "https://drdo.gov.in/drdo/en/when-was-drdo-formed"),
            _src("DRDO — Dr D.S. Kothari", "https://drdo.gov.in/drdo/en/Our-Luminaries/dr-ds-kothari"),
            _src("DRDO — Our Team", "https://drdo.gov.in/drdo/en/organisation/who-is-who"),
        ],
    },
    "ASIAN GAMES": {
        "entity": "Asian Games",
        "entity_type": "sporting_event",
        "definition": "The major multi-sport event for Asian National Olympic Committees, organised under the Olympic Council of Asia.",
        "first_edition": "New Delhi, India — 4 to 11 March 1951",
        "first_edition_facts": [
            "The first Asian Games were held in Delhi, India, from 4–11 March 1951.",
            "The Games were officially opened by President Dr Rajendra Prasad.",
            "The inaugural Games involved 11 participating National Olympic Committees and 489 athletes.",
        ],
        "institution_history": [
            "The Asian Games Federation was formed in New Delhi in 1949.",
            "The Asian Games Federation was later replaced by the Olympic Council of Asia (OCA).",
            "The OCA states that its permanent headquarters is in Kuwait.",
        ],
        "exam_traps": [
            "Do not confuse the earlier Far Eastern Championship Games and West Asian Games with the first unified Asian Games of 1951.",
            "The first unified Asian Games were held in New Delhi in 1951.",
            "New Delhi hosted the Asian Games again in 1982.",
        ],
        "sources": [
            _src("Olympic Council of Asia — New Delhi 1951", "https://oca.asia/games/107-hangzhou-2022.html"),
            _src("Olympic Council of Asia — History", "https://oca.asia/council/"),
            _src("Indian Olympic Association — New Delhi 1951", "https://olympic.ind.in/international-game/asian-games-new-delhi-1951/"),
        ],
    },
}

CATEGORY_CHECKLISTS = {
    "budget": {
        "title": "Budget / Public Finance GK",
        "fields": ["Constitutional basis (Article 112)", "Receipts and expenditure", "Revenue vs capital", "Fiscal deficit", "Revenue deficit", "Primary deficit", "FRBM framework", "Ministry/department responsible", "Key allocation and purpose", "Previous-year comparison", "Important terminology", "Prelims traps"],
    },
    "scheme": {
        "title": "Government Scheme GK",
        "fields": ["Concerned ministry", "Department", "Launch year/date", "Objective", "Target beneficiaries", "Eligibility", "Funding pattern", "Implementation agency", "Major components", "Recent changes", "Budgetary support", "Related legislation", "Prelims traps"],
    },
    "index": {
        "title": "Index / Report GK",
        "fields": ["Publisher", "Headquarters", "Frequency", "Coverage", "Indicators used", "India's rank", "India's score", "Previous rank/score", "Top-ranked entity if explicitly reported", "Methodology", "Limitations", "Prelims traps"],
    },
    "international": {
        "title": "International Organisation GK",
        "fields": ["Full form", "Established", "Headquarters", "Membership", "India's membership/status", "Current head", "Mandate", "Major reports", "Important conventions/treaties", "India-related initiatives", "Prelims traps"],
    },
    "award": {
        "title": "Awards / Honours GK",
        "fields": ["Instituted in", "Instituted by", "Purpose", "Field", "First recipient if verified", "First Indian recipient if verified", "Recent/current recipient", "Selection/awarding body", "Associated institution", "Prelims traps"],
    },
    "environment": {
        "title": "Environment & Biodiversity GK",
        "fields": ["Scientific name", "IUCN status", "CITES status", "CMS status", "Habitat", "Geographical range", "Protected areas", "Ramsar connection", "Threats", "Conservation programme", "Convention", "Prelims traps"],
    },
    "science": {
        "title": "Science & Technology GK",
        "fields": ["What is it?", "How does it work?", "Developer/organisation", "Concerned ministry/department", "First development/use if verified", "Applications", "Advantages", "Limitations", "Related missions/programmes", "Important terminology"],
    },
    "sport": {
        "title": "Sports Static GK",
        "fields": ["Sport/disciplines", "Governing body", "Founded", "Headquarters", "Olympic/Asian Games status", "First edition", "First Indian medalist/recipient if verified", "First Indian woman if verified", "Major venues", "Important records", "Rules/terminology"],
    },
    "polity": {
        "title": "Polity & Constitution GK",
        "fields": ["Constitutional Article", "Part/Schedule", "Institution", "Composition", "Appointment/election", "Tenure", "Powers/functions", "Removal", "Amendments", "Important cases/committees", "Prelims traps"],
    },
}

def detect_pack(text: str):
    t = text.upper()
    for key in PACKS:
        if key in t or (key == "ASIAN GAMES" and "ASIAN GAMES" in t):
            return key
    if "DEFENCE RESEARCH AND DEVELOPMENT ORGANISATION" in t:
        return "DRDO"
    return None

def detect_category(text: str, existing_category: str = ""):
    t = (existing_category + " " + text).lower()
    if any(x in t for x in ["budget", "fiscal deficit", "allocation", "expenditure"]): return "budget"
    if any(x in t for x in ["scheme", "yojana", "mission", "beneficiary"]): return "scheme"
    if any(x in t for x in ["index", "report", "ranking", "ranked"]): return "index"
    if any(x in t for x in ["award", "prize", "honour", "medal"]): return "award"
    if any(x in t for x in ["species", "wildlife", "forest", "biodiversity", "ramsar", "iucn"]): return "environment"
    if any(x in t for x in ["isro", "drdo", "satellite", "quantum", "ai", "semiconductor", "technology"]): return "science"
    if any(x in t for x in ["asian games", "olympic", "cricket", "football", "hockey", "athletics", "sport"]): return "sport"
    if any(x in t for x in ["constitution", "article", "parliament", "supreme court", "election commission"]): return "polity"
    if any(x in t for x in ["international", "united nations", "unesco", "unicef", "brics", "g20"]): return "international"
    return None

def enrich_article(article: dict) -> dict:
    """Attach rich static_gk without overwriting verified article facts."""
    out = deepcopy(article)
    text_blob = " ".join(str(out.get(k, "")) for k in ["title","summary","why_important","category"])
    pack_key = detect_pack(text_blob)
    cat_key = detect_category(text_blob, str(out.get("category","")))
    if pack_key:
        pack = deepcopy(PACKS[pack_key])
        pack["knowledge_type"] = "curated_entity_pack"
        pack["verification_status"] = "verified_source_pack"
        out["static_gk"] = pack
    else:
        old = out.get("static_gk") if isinstance(out.get("static_gk"), dict) else {}
        checklist = CATEGORY_CHECKLISTS.get(cat_key, {})
        out["static_gk"] = {
            **old,
            "knowledge_type": "category_enrichment_template",
            "verification_status": "needs_source_enrichment",
            "topic": out.get("title") or out.get("category") or "Current-affairs topic",
            "concept_explanation": (
                "This section is intentionally structured for exam preparation. "
                "Fields that require an external factual source are not guessed."
            ),
            "checklist": checklist.get("fields", []),
            "checklist_title": checklist.get("title", "Static GK enrichment"),
            "verified_facts": old.get("facts", old.get("key_facts", [])),
            "exam_traps": old.get("exam_traps", []),
            "sources": old.get("sources", []),
        }
    return out
