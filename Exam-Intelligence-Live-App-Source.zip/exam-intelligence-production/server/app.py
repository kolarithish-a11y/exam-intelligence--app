import asyncio, os, re, hashlib
from datetime import datetime, timezone
import feedparser, httpx
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

APP=FastAPI(title="Exam Intelligence API", version="1.1.0")
APP.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

SOURCES=[
 ("PIB",os.getenv("PIB_RSS_URL","https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=1")),
 ("RBI",os.getenv("RBI_RSS_URL","https://www.rbi.org.in/Scripts/Rss.aspx")),
]
_cache={"updated":None,"items":[],"sources":{}}
_lock=asyncio.Lock()

class Article(BaseModel):
 id:str; source:str; title:str; url:str; published_at:str|None
 category:str="National"; summary:str=""; exam_relevance:list[str]=[]; verification:str="source-observed"

def classify(title:str)->str:
 t=title.lower()
 if any(x in t for x in ["science","technology","isro","space","research","ai","quantum"]): return "Science & Technology"
 if any(x in t for x in ["environment","climate","forest","wildlife","biodiversity"]): return "Environment"
 if any(x in t for x in ["rbi","bank","inflation","economy","gdp","finance"]): return "Economy"
 if any(x in t for x in ["defence","defense","army","navy","air force","missile"]): return "Defence"
 if any(x in t for x in ["election","parliament","court","constitution","bill","minister"]): return "Polity"
 if any(x in t for x in ["sport","cricket","hockey","olympic"]): return "Sports"
 if any(x in t for x in ["un","unesco","g20","brics","summit","foreign"]): return "International"
 return "National"

async def fetch_source(name,url):
 if not url:
  return [],"disabled"
 try:
  async with httpx.AsyncClient(timeout=20,follow_redirects=True,headers={"User-Agent":"ExamIntelligence/1.1 (+https://exam-intelligence-web.onrender.com)"}) as c:
   r=await c.get(url)
   r.raise_for_status()
   parsed=feedparser.parse(r.text)
  if getattr(parsed,"bozo",False) and not parsed.entries:
   return [],f"feed parse error: {str(getattr(parsed,'bozo_exception','unknown'))[:180]}"
  items=[]
  for e in parsed.entries[:50]:
   title=re.sub(r"\s+"," ",str(e.get("title","")).strip())
   link=str(e.get("link","")).strip()
   if not title: continue
   ident=hashlib.sha256(f"{name}|{title}|{link}".encode()).hexdigest()[:16]
   items.append(Article(id=ident,source=name,title=title,url=link,published_at=e.get("published") or e.get("updated"),category=classify(title),summary=f"Source-observed item from {name}. Open the primary source for complete context.",exam_relevance=["UPSC","TGPSC"]))
  return items,f"ok:{len(items)}"
 except Exception as e:
  return [],f"error: {type(e).__name__}: {str(e)[:180]}"

async def ingest():
 async with _lock:
  all_items=[]; statuses={}
  for name,url in SOURCES:
   items,status=await fetch_source(name,url); all_items.extend(items); statuses[name]={"url":url,"status":status,"items":len(items)}
  seen=set(); unique=[]
  for x in all_items:
   key=re.sub(r"[^a-z0-9]","",x.title.lower())
   if key in seen: continue
   seen.add(key); unique.append(x)
  _cache.update(items=unique,updated=datetime.now(timezone.utc).isoformat(),sources=statuses)
  return unique

@APP.get("/")
async def root(): return {"service":"exam-intelligence-api","status":"ok","docs":"/docs"}

@APP.get("/health")
async def health(): return {"status":"ok","service":"exam-intelligence-api","cache_items":len(_cache["items"]),"last_ingest":_cache["updated"],"sources":_cache["sources"]}

@APP.get("/api/sources")
async def sources(): return _cache["sources"] or (await ingest() and _cache["sources"])

@APP.post("/api/ingest")
async def ingest_route():
 items=await ingest(); return {"status":"ok","count":len(items),"updated":_cache["updated"],"sources":_cache["sources"]}

@APP.get("/api/current-affairs",response_model=list[Article])
async def current_affairs(q:str|None=None,category:str|None=None,limit:int=50):
 if not _cache["items"]: await ingest()
 arr=_cache["items"]
 if q: arr=[x for x in arr if q.lower() in (x.title+" "+x.summary).lower()]
 if category and category!="All": arr=[x for x in arr if x.category==category]
 return arr[:min(limit,100)]

@APP.get("/api/search",response_model=list[Article])
async def search(q:str=Query(min_length=1),limit:int=30):
 if not _cache["items"]: await ingest()
 return [x for x in _cache["items"] if q.lower() in (x.title+" "+x.summary+" "+x.category).lower()][:limit]

@APP.get("/api/today")
async def today():
 items=await current_affairs(limit=100); return {"date":datetime.now().date().isoformat(),"count":len(items),"items":items}

if __name__=="__main__":
 import uvicorn
 uvicorn.run(APP,host="0.0.0.0",port=int(os.getenv("PORT","8000")))
